//: # Secure Storage
//:
//: ## Problema
//: Los tokens de autenticación, las claves API y los PIN almacenados en UserDefaults son accesibles
//: para cualquier proceso que pueda leer el contenedor de la aplicación. En el sector fintech, la exposición de credenciales
//: es un problema normativo y de responsabilidad civil, no solo un inconveniente de seguridad.
//:
//: ## Solución
//: Abstrae el acceso al llavero tras un protocolo. Esto permite que el código de producción utilice
//: el llavero real, mientras que las pruebas utilizan una simulación en memoria. Los elementos del llavero deben
//: etiquetarse con los atributos de accesibilidad adecuados; `afterFirstUnlockThisDeviceOnly`
//: suele ser adecuado para tokens que deben sobrevivir al paso a segundo plano, pero que no deben migrar
//: a otros dispositivos.
//:
//: ## Cuándo utilizarlo
//: - Tokens OAuth, tokens de actualización, identificadores de sesión
//: - PIN de usuario o cadenas de verificación biométrica
//: - Claves API que no deben aparecer en texto plano en ninguna parte del disco
//:
//: ## Cuándo NO utilizarlo
//: - Preferencias no confidenciales (utilice UserDefaults)
//: - Blobs binarios de gran tamaño (Keychain tiene límites de tamaño; utilice almacenamiento de archivos cifrados)
//: - Datos que deben compartirse entre muchas aplicaciones sin un grupo (utilice los grupos de Keychain con precaución)

import Foundation
import Security

// MARK: - Protocol

protocol SecureStore {
    func save(key: String, value: String) throws
    func retrieve(key: String) throws -> String
    func delete(key: String) throws
}

// MARK: - Keychain Error

enum KeychainError: Error, LocalizedError {
    case itemNotFound
    case duplicateItem
    case unexpectedData
    case unhandled(OSStatus)

    var errorDescription: String? {
        switch self {
        case .itemNotFound: return "Item not found in Keychain"
        case .duplicateItem: return "Item already exists in Keychain"
        case .unexpectedData: return "Data could not be encoded or decoded"
        case .unhandled(let status): return "Keychain OSStatus: \(status)"
        }
    }
}

// MARK: - Production Keychain Implementation

struct KeychainStore: SecureStore {
    private let service: String

    init(service: String = Bundle.main.bundleIdentifier ?? "com.app.keychain") {
        self.service = service
    }

    func save(key: String, value: String) throws {
        guard let data = value.data(using: .utf8) else {
            throw KeychainError.unexpectedData
        }

        let query: [String: Any] = [
            kSecClass as String:            kSecClassGenericPassword,
            kSecAttrService as String:      service,
            kSecAttrAccount as String:      key,
            kSecValueData as String:        data,
            kSecAttrAccessible as String:   kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        ]

        let status = SecItemAdd(query as CFDictionary, nil)

        switch status {
        case errSecSuccess: break
        case errSecDuplicateItem: throw KeychainError.duplicateItem
        default: throw KeychainError.unhandled(status)
        }
    }

    func retrieve(key: String) throws -> String {
        let query: [String: Any] = [
            kSecClass as String:        kSecClassGenericPassword,
            kSecAttrService as String:  service,
            kSecAttrAccount as String:  key,
            kSecReturnData as String:   true,
            kSecMatchLimit as String:   kSecMatchLimitOne
        ]

        var result: AnyObject?
        let status = SecItemCopyMatching(query as CFDictionary, &result)

        guard status == errSecSuccess else {
            if status == errSecItemNotFound { throw KeychainError.itemNotFound }
            throw KeychainError.unhandled(status)
        }

        guard let data = result as? Data,
              let value = String(data: data, encoding: .utf8) else {
            throw KeychainError.unexpectedData
        }

        return value
    }

    func delete(key: String) throws {
        let query: [String: Any] = [
            kSecClass as String:        kSecClassGenericPassword,
            kSecAttrService as String:  service,
            kSecAttrAccount as String:  key
        ]

        let status = SecItemDelete(query as CFDictionary)
        guard status == errSecSuccess || status == errSecItemNotFound else {
            throw KeychainError.unhandled(status)
        }
    }
}

// MARK: - In-Memory Mock (for tests and playgrounds)

final class InMemorySecureStore: SecureStore {
    private var storage: [String: String] = [:]

    func save(key: String, value: String) throws {
        if storage[key] != nil { throw KeychainError.duplicateItem }
        storage[key] = value
        print("[InMemoryStore] Saved key: \(key)")
    }

    func retrieve(key: String) throws -> String {
        guard let value = storage[key] else { throw KeychainError.itemNotFound }
        return value
    }

    func delete(key: String) throws {
        storage.removeValue(forKey: key)
        print("[InMemoryStore] Deleted key: \(key)")
    }
}

// MARK: - Token Manager

final class TokenManager {
    private let store: SecureStore
    private let tokenKey = "auth.access_token"
    private let refreshKey = "auth.refresh_token"

    init(store: SecureStore) {
        self.store = store
    }

    // Nota: estas dos escrituras no son atómicas. Si la segunda falla tras el éxito
    // de la primera, la sesión queda en un estado parcial (access token guardado,
    // refresh token no). Un sistema real necesitaría una escritura compuesta o un
    // paso de compensación para revertir la primera escritura ante ese fallo.
    func persist(accessToken: String, refreshToken: String) throws {
        try store.save(key: tokenKey, value: accessToken)
        try store.save(key: refreshKey, value: refreshToken)
    }

    func accessToken() throws -> String {
        try store.retrieve(key: tokenKey)
    }

    func clearSession() throws {
        try store.delete(key: tokenKey)
        try store.delete(key: refreshKey)
    }
}

// MARK: - Usage (using mock in playground — real Keychain requires entitlements)

let secureStore = InMemorySecureStore()
let tokenManager = TokenManager(store: secureStore)

do {
    try tokenManager.persist(
        accessToken: "eyJhbGciOiJSUzI1NiJ9.access.token",
        refreshToken: "eyJhbGciOiJSUzI1NiJ9.refresh.token"
    )

    let token = try tokenManager.accessToken()
    print("Retrieved token: \(String(token.prefix(20)))...")

    try tokenManager.clearSession()
    print("Session cleared")

    _ = try tokenManager.accessToken() // Should throw
} catch KeychainError.itemNotFound {
    print("Confirmed: token not found after clearSession()")
} catch {
    print("Unexpected error: \(error)")
}

//: ## Consejo clave
//: Nunca registres los valores de los tokens, ni siquiera en compilaciones de depuración. Utiliza `kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly`
//: en lugar de `kSecAttrAccessibleAlways`: el primero requiere que el dispositivo se desbloquee al menos una vez tras
//: el reinicio, lo que impide la extracción de dispositivos apagados. El sufijo `ThisDeviceOnly` impide
//: la sincronización del llavero de iCloud, lo cual es adecuado para tokens de sesión que tienen un ámbito limitado al dispositivo.
