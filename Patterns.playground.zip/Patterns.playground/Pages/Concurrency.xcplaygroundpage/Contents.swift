//: # Concurrency
//:
//: ## Problema
//: Un panel financiero debe cargar el saldo de la cuenta, las transacciones pendientes y la puntuación crediticia
//: de forma paralela. Las llamadas asíncronas secuenciales tardan tres veces más de lo necesario. Sin embargo, una ejecución paralela
//: simplista puede provocar condiciones de carrera cuando el estado mutable compartido se actualiza
//: desde varias tareas concurrentes.
//:
//: ## Solución
//: Utiliza `async let` para el paralelismo estructurado. Utiliza `actor` para proteger el estado mutable compartido
//: del acceso concurrente. Utiliza `TaskGroup` cuando el número de operaciones paralelas
//: sea dinámico.
//:
//: ## Cuándo utilizarlo
//: - Múltiples llamadas de red independientes que pueden ejecutarse en paralelo
//: - Estado compartido actualizado por tareas concurrentes (utilice actores)
//: - Patrones de fan-out: despache N tareas, recopile resultados
//:
//: ## Cuándo NO utilizarlo
//: - Operaciones secuenciales en las que cada paso depende del resultado anterior
//: - Llamadas asíncronas simples y únicas que no se benefician de la sobrecarga del paralelismo

import Foundation

// MARK: - Domain Models

struct AccountBalance {
    let accountID: String
    let available: Decimal
    let pending: Decimal
}

struct CreditScore {
    let score: Int
    let band: String
}

struct PendingTransaction {
    let id: UUID
    let amount: Decimal
    let merchant: String
}

// MARK: - Simulated API Layer

func fetchBalance(accountID: String) async throws -> AccountBalance {
    try await Task.sleep(nanoseconds: 200_000_000)
    return AccountBalance(accountID: accountID, available: 4_820.50, pending: 320.00)
}

func fetchCreditScore(userID: String) async throws -> CreditScore {
    try await Task.sleep(nanoseconds: 300_000_000)
    return CreditScore(score: 742, band: "Good")
}

func fetchPendingTransactions(accountID: String) async throws -> [PendingTransaction] {
    try await Task.sleep(nanoseconds: 150_000_000)
    return [
        PendingTransaction(id: UUID(), amount: -24.99, merchant: "Amazon"),
        PendingTransaction(id: UUID(), amount: -8.50, merchant: "Coffee Shop"),
    ]
}

// MARK: - Parallel Loading with async let

func loadDashboard(accountID: String, userID: String) async throws {
    let start = Date()

    async let balance = fetchBalance(accountID: accountID)
    async let creditScore = fetchCreditScore(userID: userID)
    async let pendingTxns = fetchPendingTransactions(accountID: accountID)

    let (resolvedBalance, resolvedScore, resolvedTxns) = try await (balance, creditScore, pendingTxns)

    let elapsed = Date().timeIntervalSince(start)
    print(String(format: "Dashboard loaded in %.2fs (parallel)", elapsed))
    print("Balance: \(resolvedBalance.available)")
    print("Credit score: \(resolvedScore.score) (\(resolvedScore.band))")
    print("Pending transactions: \(resolvedTxns.count)")
}

// MARK: - Actor for Safe Shared State

actor TransactionAccumulator {
    private(set) var total: Decimal = 0
    private(set) var count: Int = 0

    func record(amount: Decimal) {
        total += amount
        count += 1
    }

    func summary() -> String {
        "Processed \(count) transactions. Total: \(total)"
    }
}

// MARK: - Dynamic Fan-Out with TaskGroup

func processMultipleAccounts(accountIDs: [String]) async throws {
    let accumulator = TransactionAccumulator()

    try await withThrowingTaskGroup(of: [PendingTransaction].self) { group in
        for id in accountIDs {
            group.addTask {
                try await fetchPendingTransactions(accountID: id)
            }
        }

        for try await transactions in group {
            for tx in transactions {
                await accumulator.record(amount: tx.amount)
            }
        }
    }

    let summary = await accumulator.summary()
    print("Multi-account summary: \(summary)")
}

// MARK: - Execution

Task {
    try await loadDashboard(accountID: "acc_001", userID: "usr_882")

    let accounts = ["acc_001", "acc_002", "acc_003"]
    try await processMultipleAccounts(accountIDs: accounts)
}

//: ## Idea clave
//: `async let` es concurrencia estructurada: si una rama lanza un error, todas las tareas hermanas se
//: cancelan automáticamente. Los actores serializan el acceso a su estado interno, lo que elimina
//: las carreras de datos sin necesidad de bloqueos manuales. Nunca utilices `DispatchQueue` para código nuevo de concurrencia en Swift
//:; en su lugar, utiliza actores y tareas estructuradas.
