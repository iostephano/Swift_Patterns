//: # Modularization
//:
//: ## Problema
//: Una aplicación fintech monolítica en la que Cartera, Transacciones y Análisis comparten un único
//: objetivo compila todo junto, dificulta el desarrollo en paralelo por equipos y
//: crea un acoplamiento implícito en el que un cambio en el formato de las transacciones rompe la interfaz de usuario de la cartera.
//:
//: ## Solución
//: Definir límites de módulos explícitos mediante protocolos y espacios de nombres. Cada característica posee
//: su modelo de dominio, su interfaz de servicio y su lógica de presentación. La comunicación entre características
//: se produce a través de contratos compartidos, no de componentes internos compartidos.
//:
//: En un proyecto real de Xcode, cada módulo de los siguientes sería un paquete Swift independiente o
//: un objetivo de marco. En este entorno de pruebas, el uso de espacios de nombres mediante enumeraciones simula esa estructura.
//:
//: ## Cuándo utilizarlo
//: - Equipos con más de tres ingenieros que trabajan en diferentes características simultáneamente
//: - Características que requieren una implementación independiente o el uso de indicadores de características
//: - Cuando se desea aplicar límites arquitectónicos en tiempo de compilación
//:
//: ## Cuándo NO utilizarlo
//: - Proyectos individuales o equipos muy pequeños en los que la sobrecarga del módulo supera los beneficios
//: - Proyectos en fase inicial en los que aún se están definiendo los límites

import Foundation

// MARK: - Module: Wallet

enum WalletModule {

    struct Balance {
        let amount: Decimal
        let currency: String
        let lastUpdated: Date
    }

    protocol WalletService {
        func fetchBalance(for accountID: String) async throws -> Balance
    }

    struct LiveWalletService: WalletService {
        func fetchBalance(for accountID: String) async throws -> Balance {
            return Balance(amount: 12_450.75, currency: "USD", lastUpdated: Date())
        }
    }

    struct WalletViewModel {
        private let service: WalletService

        init(service: WalletService) {
            self.service = service
        }

        func loadBalance(for accountID: String) async -> String {
            do {
                let balance = try await service.fetchBalance(for: accountID)
                return "\(balance.currency) \(balance.amount)"
            } catch {
                return "Unavailable"
            }
        }
    }
}

// MARK: - Module: Transactions

enum TransactionsModule {

    struct Transaction {
        let id: UUID
        let amount: Decimal
        let merchant: String
        let category: Category
        let date: Date

        enum Category: String {
            case food, transport, shopping, salary, transfer, other
        }
    }

    protocol TransactionService {
        func fetchRecent(for accountID: String, limit: Int) async throws -> [Transaction]
    }

    struct LiveTransactionService: TransactionService {
        func fetchRecent(for accountID: String, limit: Int) async throws -> [Transaction] {
            return [
                Transaction(id: UUID(), amount: -23.50, merchant: "Uber Eats",
                            category: .food, date: Date()),
                Transaction(id: UUID(), amount: -9.99, merchant: "Netflix",
                            category: .shopping, date: Date()),
                Transaction(id: UUID(), amount: 3200.00, merchant: "Employer Inc",
                            category: .salary, date: Date()),
            ].prefix(limit).map { $0 }
        }
    }
}

// MARK: - Module: Analytics

enum AnalyticsModule {

    struct SpendingReport {
        let category: TransactionsModule.Transaction.Category
        let totalSpent: Decimal
        let transactionCount: Int
    }

    struct SpendingAnalyzer {
        func analyze(transactions: [TransactionsModule.Transaction]) -> [SpendingReport] {
            var grouped: [TransactionsModule.Transaction.Category: [Decimal]] = [:]
            for tx in transactions where tx.amount < 0 {
                grouped[tx.category, default: []].append(abs(tx.amount))
            }
            return grouped.map { category, amounts in
                SpendingReport(
                    category: category,
                    totalSpent: amounts.reduce(0, +),
                    transactionCount: amounts.count
                )
            }.sorted { $0.totalSpent > $1.totalSpent }
        }
    }
}

// MARK: - App Composition Layer

Task {
    let walletVM = WalletModule.WalletViewModel(service: WalletModule.LiveWalletService())
    let txService = TransactionsModule.LiveTransactionService()
    let analyzer = AnalyticsModule.SpendingAnalyzer()

    let balance = await walletVM.loadBalance(for: "acc_001")
    print("Balance: \(balance)")

    let transactions = try await txService.fetchRecent(for: "acc_001", limit: 10)
    print("Transactions loaded: \(transactions.count)")

    let report = analyzer.analyze(transactions: transactions)
    for item in report {
        print("Category: \(item.category.rawValue) — Total: \(item.totalSpent)")
    }
}
