//: # Dependency Injection
//:
//: ## Problema
//: Un servicio de pagos que crea internamente su propio cliente de red, registrador y rastreador de análisis
//: no puede someterse a pruebas sin acceder a puntos finales reales. En el sector fintech, todas las
//: rutas críticas para el negocio deben poder someterse a pruebas completas con entradas controladas.
//:
//: ## Solución
//: Define el comportamiento detrás de los protocolos. Inyecta implementaciones concretas en la raíz de la composición
//: (punto de entrada de la aplicación). Utiliza implementaciones simuladas en las pruebas. No se requiere ningún contenedor DI de terceros
//: — los protocolos Swift y la inyección de inicializadores son suficientes.
//:
//: ## Cuándo utilizarlo
//: - Cualquier servicio que realice E/S (red, disco, llavero)
//: - Análisis y registro que deben ser intercambiables o silenciables en las pruebas
//: - Indicadores de características que varían entre entornos
//:
//: ## Cuándo NO utilizarlo
//: - Transformaciones de tipos de valor puros sin efectos secundarios (no se necesita inyección)
//: - Utilidades triviales sin implementaciones variantes significativas

import Foundation

// MARK: - Protocols (Ports)

protocol PaymentGateway {
    func charge(amount: Decimal, currency: String, token: String) async throws -> String
}

protocol TransactionLogger {
    func log(event: String, metadata: [String: String])
}

protocol FraudDetector {
    func evaluate(amount: Decimal, token: String) async -> Bool
}

// MARK: - Production Implementations (Adapters)

struct StripeGateway: PaymentGateway {
    func charge(amount: Decimal, currency: String, token: String) async throws -> String {
        print("[Stripe] Charging \(currency) \(amount) with token \(token)")
        return "stripe_txn_\(UUID().uuidString.prefix(8))"
    }
}

struct DatadogLogger: TransactionLogger {
    func log(event: String, metadata: [String: String]) {
        print("[Datadog] \(event) — \(metadata)")
    }
}

struct MLFraudDetector: FraudDetector {
    func evaluate(amount: Decimal, token: String) async -> Bool {
        print("[FraudML] Evaluating transaction for risk")
        return amount < 10_000
    }
}

// MARK: - Payment Service (Consumer of Dependencies)

final class PaymentService {
    private let gateway: PaymentGateway
    private let logger: TransactionLogger
    private let fraudDetector: FraudDetector

    init(
        gateway: PaymentGateway,
        logger: TransactionLogger,
        fraudDetector: FraudDetector
    ) {
        self.gateway = gateway
        self.logger = logger
        self.fraudDetector = fraudDetector
    }

    func processPayment(amount: Decimal, currency: String, token: String) async throws -> String {
        logger.log(event: "payment.initiated", metadata: [
            "amount": "\(amount)",
            "currency": currency
        ])

        let isSafe = await fraudDetector.evaluate(amount: amount, token: token)
        guard isSafe else {
            logger.log(event: "payment.blocked_fraud", metadata: ["token": token])
            throw PaymentError.fraudDetected
        }

        let transactionID = try await gateway.charge(amount: amount, currency: currency, token: token)
        logger.log(event: "payment.success", metadata: ["txn_id": transactionID])
        return transactionID
    }

    enum PaymentError: Error {
        case fraudDetected
        case gatewayFailure(String)
    }
}

// MARK: - Test Doubles

struct MockGateway: PaymentGateway {
    var shouldFail = false
    func charge(amount: Decimal, currency: String, token: String) async throws -> String {
        if shouldFail { throw PaymentService.PaymentError.gatewayFailure("mock failure") }
        return "mock_txn_success"
    }
}

struct MockLogger: TransactionLogger {
    var logged: [String] = []
    mutating func log(event: String, metadata: [String: String]) {
        logged.append(event)
        print("[MockLogger] \(event)")
    }
}

struct MockFraudDetector: FraudDetector {
    var isSafe: Bool
    func evaluate(amount: Decimal, token: String) async -> Bool { isSafe }
}

// MARK: - Usage

Task {
    let productionService = PaymentService(
        gateway: StripeGateway(),
        logger: DatadogLogger(),
        fraudDetector: MLFraudDetector()
    )

    do {
        let txnID = try await productionService.processPayment(
            amount: 250.00,
            currency: "USD",
            token: "tok_visa_4242"
        )
        print("Transaction completed: \(txnID)")
    } catch {
        print("Payment failed: \(error)")
    }

    let testService = PaymentService(
        gateway: MockGateway(),
        logger: MockLogger(),
        fraudDetector: MockFraudDetector(isSafe: true)
    )

    let testTxn = try? await testService.processPayment(
        amount: 50.00,
        currency: "USD",
        token: "tok_test"
    )
    print("Test transaction: \(testTxn ?? "nil")")
}
