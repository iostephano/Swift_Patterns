//: # Lazy Loading
//:
//: ## Problema
//: Los paneles financieros agregan datos de múltiples fuentes: saldos de cuentas,
//: transacciones recientes, puntuaciones crediticias, carteras de inversión. Cargar todo esto
//: al iniciar la aplicación ralentiza la experiencia, hace que la aplicación no responda y desperdicia ancho de banda de red
//: en datos que el usuario quizá nunca llegue a ver en una sesión.
//:
//: ## Solución
//: Aplaza la inicialización costosa hasta el momento en que los datos sean realmente necesarios.
//: La palabra clave `lazy` de Swift gestiona el aplazamiento a nivel de propiedad. Para el aplazamiento a nivel de servicio,
//: es más adecuado un cierre de fábrica o un patrón de estado de carga.
//:
//: ## Cuándo utilizarlo
//: - Cálculos pesados o llamadas de red vinculadas a componentes de la interfaz de usuario que no siempre se muestran
//: - Widgets de paneles de control que se cargan por debajo del pliegue
//: - Funciones restringidas por permisos de usuario (puede que nunca sean necesarias)
//:
//: ## Cuándo NO utilizarlo
//: - Cuando los datos siempre se necesitan de inmediato en la primera representación
//: - Cuando la inicialización diferida crearía problemas de subprocesos (lazy no es seguro para subprocesos)
//: - Cuando el fallo de inicialización debe gestionarse en el momento de la construcción

import Foundation

// MARK: - Domain Models

struct Transaction {
    let id: UUID
    let amount: Decimal
    let description: String
    let date: Date
}

struct AccountSummary {
    let balance: Decimal
    let currency: String
    let accountNumber: String
}

// MARK: - Simulated Data Sources

func fetchTransactionHistory() -> [Transaction] {
    print("[LazyLoading] fetchTransactionHistory() called — expensive operation")
    return [
        Transaction(id: UUID(), amount: 1200.00, description: "Salary", date: Date()),
        Transaction(id: UUID(), amount: -45.99, description: "Subscription", date: Date()),
        Transaction(id: UUID(), amount: -120.00, description: "Grocery", date: Date()),
    ]
}

func fetchAccountSummary() -> AccountSummary {
    print("[LazyLoading] fetchAccountSummary() called — expensive operation")
    return AccountSummary(balance: 8450.00, currency: "USD", accountNumber: "****4821")
}

// MARK: - Dashboard View Model

final class LazyDashboardViewModel {

    private(set) lazy var accountSummary: AccountSummary = {
        fetchAccountSummary()
    }()

    private(set) lazy var transactionHistory: [Transaction] = {
        fetchTransactionHistory()
    }()

    var displayBalance: String {
        let summary = accountSummary
        return "\(summary.currency) \(summary.balance)"
    }
}

// MARK: - Usage Simulation

let viewModel = LazyDashboardViewModel()

print("App launched. Rendering header...")
print("Balance: \(viewModel.displayBalance)")

print("\nUser opened transaction list...")
let transactions = viewModel.transactionHistory
print("Loaded \(transactions.count) transactions")

print("\nAccessing transactions again...")
_ = viewModel.transactionHistory
print("No additional fetch — value already initialized")

//: ## Idea clave
//: El uso de `lazy var` en una propiedad de clase ejecuta el cierre exactamente una vez, en el primer acceso.
//: Para garantizar la seguridad entre subprocesos en contextos concurrentes, es preferible utilizar una inicialización explícita con
//: un actor o un mecanismo de sincronización; el uso de `lazy` por sí solo no garantiza la seguridad entre subprocesos.
