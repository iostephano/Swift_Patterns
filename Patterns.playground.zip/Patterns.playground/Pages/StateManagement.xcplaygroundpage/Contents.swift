//: # State Management
//:
//: ## Problema
//: Un flujo de pago tiene varios estados: inactivo, cargando, correcto, fallido. Si estos estados
//: se representan como valores booleanos dispersos (`isLoading`, `hasError`, `isSuccess`), es
//: posible llegar a estados imposibles como `isLoading = true` e `isSuccess = true`
//: al mismo tiempo. Estos errores son difíciles de reproducir y pueden tener consecuencias catastróficas en el sector fintech.
//:
//: ## Solución
//: Modele el estado como una única enumeración con valores asociados. Utilice un flujo unidireccional:
//: Se envían las acciones, un reductor genera un nuevo estado y la interfaz de usuario reacciona al estado.
//: Esto hace que los estados imposibles sean irrepresentables y que las transiciones de estado sean explícitas y auditables.
//:
//: ## Cuándo utilizarlo
//: - Cualquier flujo de varios pasos con estados intermedios significativos (incorporación, pago, KYC)
//: - Flujos en los que el estado debe registrarse o reproducirse para la depuración o el cumplimiento normativo
//:
//: ## Cuándo NO utilizarlo
//: - Pantallas sencillas de un solo paso con una única llamada asíncrona y sin lógica de ramificación
//: - Vistas de presentación sin estado

import Foundation

// MARK: - Domain

struct PaymentRequest {
    let amount: Decimal
    let recipientID: String
    let currency: String
}

struct PaymentReceipt {
    let transactionID: String
    let confirmedAt: Date
    let amount: Decimal
}

// MARK: - State

enum PaymentState: CustomStringConvertible {
    case idle
    case validating(PaymentRequest)
    case processing(PaymentRequest)
    case succeeded(PaymentReceipt)
    case failed(PaymentFailure)

    var description: String {
        switch self {
        case .idle: return "idle"
        case .validating(let req): return "validating \(req.currency) \(req.amount)"
        case .processing(let req): return "processing \(req.currency) \(req.amount)"
        case .succeeded(let receipt): return "succeeded — txn \(receipt.transactionID)"
        case .failed(let failure): return "failed — \(failure.reason)"
        }
    }
}

enum PaymentFailure {
    case insufficientFunds
    case recipientNotFound
    case networkError(String)
    case fraudBlock

    var reason: String {
        switch self {
        case .insufficientFunds: return "Insufficient funds"
        case .recipientNotFound: return "Recipient not found"
        case .networkError(let msg): return "Network error: \(msg)"
        case .fraudBlock: return "Transaction blocked by fraud detection"
        }
    }
}

// MARK: - Actions

enum PaymentAction {
    case submitPayment(PaymentRequest)
    case validationPassed
    case validationFailed(PaymentFailure)
    case processingCompleted(PaymentReceipt)
    case processingFailed(PaymentFailure)
    case reset
}

// MARK: - Reducer

func paymentReducer(state: PaymentState, action: PaymentAction) -> PaymentState {
    switch (state, action) {
    case (.idle, .submitPayment(let request)):
        return .validating(request)

    case (.validating(let request), .validationPassed):
        return .processing(request)

    case (.validating, .validationFailed(let failure)):
        return .failed(failure)

    case (.processing, .processingCompleted(let receipt)):
        return .succeeded(receipt)

    case (.processing, .processingFailed(let failure)):
        return .failed(failure)

    case (_, .reset):
        return .idle

    default:
        print("Warning: invalid action \(action) for state \(state)")
        return state
    }
}

// MARK: - Store

@MainActor
final class PaymentStore: ObservableObject {
    @Published private(set) var state: PaymentState = .idle

    func dispatch(_ action: PaymentAction) {
        let newState = paymentReducer(state: state, action: action)
        print("Transition: \(state) → \(newState)")
        state = newState
    }
}

// MARK: - Simulated Flow

Task { @MainActor in
    let store = PaymentStore()

    let request = PaymentRequest(amount: 500.00, recipientID: "usr_7821", currency: "USD")

    store.dispatch(.submitPayment(request))
    try await Task.sleep(nanoseconds: 100_000_000)
    store.dispatch(.validationPassed)

    try await Task.sleep(nanoseconds: 100_000_000)
    let receipt = PaymentReceipt(
        transactionID: "txn_\(UUID().uuidString.prefix(8))",
        confirmedAt: Date(),
        amount: request.amount
    )
    store.dispatch(.processingCompleted(receipt))

    print("\nFinal state: \(store.state)")

    store.dispatch(.validationPassed)
}
