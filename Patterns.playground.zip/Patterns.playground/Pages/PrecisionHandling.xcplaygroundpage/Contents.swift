//: # Precision Handling
//:
//: ## Problema
//: La aritmética de coma flotante IEEE 754 no puede representar con exactitud la mayoría de las fracciones decimales.
//: 0,1 + 0,2 no es igual a 0,3 en el tipo Double. En una aplicación financiera, estos errores se acumulan
//: a lo largo de miles de transacciones, lo que genera desequilibrios contables difíciles de rastrear
//: e imposibles de explicar ante un organismo regulador.
//:
//: ## Solución
//: Utilice `Decimal` (puente NSDecimalNumber) para todos los valores monetarios. Defina reglas de redondeo explícitas.
//: Nunca muestre ni almacene valores Double intermedios en rutas financieras.
//:
//: ## Cuándo utilizarlo
//: - Toda aritmética monetaria: totales, intereses, comisiones, cálculos de impuestos
//: - Cualquier valor que se vaya a almacenar, transmitir o comparar en un contexto financiero
//:
//: ## Cuándo NO utilizarlo
//: - Animaciones de la interfaz de usuario, física, geometría: Decimal es más lento, utilice Double en esos casos
//: - Datos de sensores, entradas de ML: una precisión superior a la de Double rara vez es significativa

import Foundation

// MARK: - The Problem

print("=== Floating Point Representation Error ===")
let a: Double = 0.1
let b: Double = 0.2
let doubleSum = a + b
print("Double: 0.1 + 0.2 = \(doubleSum)")

var runningDouble: Double = 0
for _ in 0..<1000 {
    runningDouble += 0.1
}
print("Double: 0.1 × 1000 = \(runningDouble)")

// MARK: - The Solution

print("\n=== Decimal Precision ===")
let x: Decimal = 0.1
let y: Decimal = 0.2
let decimalSum = x + y
print("Decimal: 0.1 + 0.2 = \(decimalSum)")

var runningDecimal: Decimal = 0
for _ in 0..<1000 {
    runningDecimal += Decimal(string: "0.1")!
}
print("Decimal: 0.1 × 1000 = \(runningDecimal)")

// MARK: - Rounding Rules

struct MoneyRounder {
    let scale: Int
    let roundingMode: NSDecimalNumber.RoundingMode

    func round(_ value: Decimal) -> Decimal {
        var result = value
        var rounded = Decimal()
        NSDecimalRound(&rounded, &result, scale, roundingMode)
        return rounded
    }
}

let bankingRounder = MoneyRounder(scale: 2, roundingMode: .bankers)
let standardRounder = MoneyRounder(scale: 2, roundingMode: .plain)

let rawFee = Decimal(string: "12.5450001")!
print("\nRaw fee: \(rawFee)")
print("Banker's rounding (scale 2): \(bankingRounder.round(rawFee))")
print("Standard rounding (scale 2): \(standardRounder.round(rawFee))")

// MARK: - Money Value Type

struct Money: CustomStringConvertible, Equatable {
    let amount: Decimal
    let currency: String

    private static let rounder = MoneyRounder(scale: 2, roundingMode: .bankers)

    init(amount: Decimal, currency: String) {
        self.amount = Money.rounder.round(amount)
        self.currency = currency
    }

    // `precondition` es intencional aquí: mezclar monedas en una suma es un error
    // de programador, no una condición esperada en tiempo de ejecución. Los datos
    // externos (montos y monedas que vienen de una API o de un usuario) deben
    // validarse en el borde del sistema, antes de construir un Money, no aquí.
    static func + (lhs: Money, rhs: Money) -> Money {
        precondition(lhs.currency == rhs.currency, "Currency mismatch: \(lhs.currency) + \(rhs.currency)")
        return Money(amount: lhs.amount + rhs.amount, currency: lhs.currency)
    }

    // Misma razón que en `+`: invariante de programador, no un error recuperable.
    static func - (lhs: Money, rhs: Money) -> Money {
        precondition(lhs.currency == rhs.currency, "Currency mismatch")
        return Money(amount: lhs.amount - rhs.amount, currency: lhs.currency)
    }

    func applying(taxRate: Decimal) -> Money {
        Money(amount: amount * (1 + taxRate), currency: currency)
    }

    var description: String { "\(currency) \(amount)" }
}

print("\n=== Money Value Type ===")
let price = Money(amount: Decimal(string: "99.994")!, currency: "USD")
let tax = Decimal(string: "0.085")!
let total = price.applying(taxRate: tax)
print("Price: \(price)")
print("After 8.5% tax: \(total)")

let fee = Money(amount: Decimal(string: "5.50")!, currency: "USD")
print("Price + fee: \(price + fee)")

// MARK: - Safe Parsing from External Sources

func parseMoney(from string: String, currency: String) -> Money? {
    guard let value = Decimal(string: string) else { return nil }
    return Money(amount: value, currency: currency)
}

let fromAPI = parseMoney(from: "1234.56", currency: "EUR")
print("\nParsed from API: \(fromAPI?.description ?? "parse error")")

//: ## Consejo clave
//: Nunca cree objetos `Decimal` a partir de `Double` (el tipo `Decimal(0.1)` hereda la imprecisión de `Double`).
//: Utilice siempre Decimal(string:) o construcciones basadas en enteros (Decimal(100) / Decimal(3)).
//: Defina y centralice su modo de redondeo; debe ser coherente en todo el
//: proceso de cálculo financiero.
